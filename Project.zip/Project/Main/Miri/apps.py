from django.apps import AppConfig


class MiriConfig(AppConfig):
    name = 'Miri'
